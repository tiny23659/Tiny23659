# Tiny236599
1. YouTube.  https://youtube.com/@laado-t4b?si=Io6aH4DH4Y3at7cy   2. Facebook. https://www.facebook.com/share/1DpAmUyQZx/   3. Facebook page.  https://www.facebook.com/share/1H3gvMdfxg/   4. Instgram. https://www.instagram.com/tiny_ai_23?stkn=bTNqeTF4dTdwNzZt User .@tiny_ai_23    Make hyper link
